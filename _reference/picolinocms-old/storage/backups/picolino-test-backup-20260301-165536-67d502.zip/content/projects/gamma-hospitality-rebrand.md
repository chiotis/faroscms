---
title: Gamma Hospitality Rebrand
status: published
visible: true
date: 2025-11-10
translation_id: c3d4e5f60718293a
excerpt: "Επανατοποθέτηση brand φιλοξενίας με ενιαία εμπειρία σε web και offline touchpoints."
main_image: /uploads/images/envato-labs-ai-f132598b-f38e-4342-97b6-8cc96b556edd.jpg
tags:
  - strategy
  - growth
categories:
  - case-studies
custom_fields:
  client: Gamma Hotels Group
  location: Athens, GR
  duration: 10 εβδομάδες
---
Σχεδιάσαμε νέο narrative, βελτιώσαμε conversion paths και ανανεώσαμε τα βασικά assets του brand.
